import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import {CoursesJsonService} from '../courses-json.service';
import {CourseList} from '../CourseList';
import { NgModule } from '@angular/core';

@Component({
  selector: 'app-courses-json',
  templateUrl: './courses-json.component.html',
  styleUrls: ['./courses-json.component.css']
})
export class CoursesJsonComponent implements OnInit {

  constructor(private coursesService:CoursesJsonService) { }
  courses:CourseList[];

  ngOnInit() {
    this.getCourseList();
  }

  getCourseList():void{
      this.coursesService.getCourseList().subscribe(courses=>this.courses=courses);
    }
}