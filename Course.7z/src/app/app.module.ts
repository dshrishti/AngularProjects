import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule} from '@angular/router';

import { AppComponent } from './app.component';
import { MainComponent } from './main/main.component';
import { CoursesComponent } from './courses/courses.component';
import { CoursesJsonComponent } from './courses-json/courses-json.component';

@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    CoursesComponent,
    CoursesJsonComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
         {
            path: '',
            component: MainComponent
         },
         {
            path: 'Courses',
            component: CoursesComponent
         },
         {
            path: 'CoursesJson',
            component: CoursesJsonComponent
         }
      ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
