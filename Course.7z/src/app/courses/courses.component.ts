import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {
  
  courses:any[]=[
    {name:"Course 1",duration:3},
    {name:"Course 2",duration:4},
    {name:"Course 3",duration:5},
    {name:"Course 4",duration:2},
    {name:"Course 5",duration:7},
    {name:"Course 6",duration:3},
    {name:"Course 7",duration:5},
    {name:"Course 8",duration:7},
    {name:"Course 9",duration:3},
    {name:"Course 10",duration:4}
  ]
  constructor() { }

  Add(courseValues:any){
    this.courses.push({name:courseValues.CourseName,duration:courseValues.CourseDuration});
  }
 
  Search(cName:any){
    var flag=0
      for(let c  of this.courses)
      {
        if(c.name===cName.CourseToSearch)
        {
          alert(c.duration)
          flag=1;
        }
      }
      if(flag==0){
        alert("Course not found");
      }
  }

  ngOnInit() {
  }

}
