export interface CourseList{
    courseId:number;
    courseName:string;
    coursePrice:any;
}