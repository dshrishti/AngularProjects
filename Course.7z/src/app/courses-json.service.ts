import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import {CourseList} from './CourseList';
import { NgModule } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CoursesJsonService {

  constructor(private httpClient:HttpClient) {}
  public url='../assets/courses.json';

  ngOnInit(){
    this.getCourseList();
}

  getCourseList():Observable<CourseList[]>{
  return this.httpClient.get<CourseList[]>(this.url);
}
}
