var http=require('http');
var exp=require('express');
var app=exp();
var fs=require('fs');
var cors=require('cors');
var data=require('./products.json');
var parser=require('body-parser');
app.use(cors());
app.use(parser.json());

//api to get data from file and displaying on browser

app.route('/getData',cors()).get((req,res)=>{
     console.log("Get data invoked");
     res.send(data);
     res.end();
});

//api to delete data

app.route('/deleteData/:id',cors()).delete((req,res)=>{
    console.log("Delete Data invoked");
    proId=req.params.id;
    for(d in data)
    {
        if(data[d].productId==proId)
        {
            data.splice(d,1);
        }
        break;
    }
    res.send(data);
    fs.writeFileSync("products.json",JSON.stringify(data));
});

//api to add data

app.route('/addData',cors()).post((req,res)=>{
    console.log("Add data invoked");
    var x=data;
    x.push(req.body);
    fs.writeFileSync("products.json",JSON.stringify(x));
    res.send(x);
});

app.listen(3000,function(){
    console.log("Running");
});