import { Injectable, OnInit} from '@angular/core';
import {IProducts} from './IProduct';
import { HttpClient } from '@angular/common/http'; 
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductDisplayService {

  constructor(private http:HttpClient) { }

  ngOnInit(){
      this.getData();
  }

  getData():Observable<any>{
        return this.http.get<any[]>('http://localhost:3000/getData');
  }

  DeleteData(proId):Observable<any>{
      return this.http.delete<any[]>('http://localhost:3000/deleteData/'+proId);
  }

  postData(pId:number,pName:string,pDes:string,pPrice:number):Observable<any>{
    return this.http.post<any[]>('http://localhost:3000/addData',{
      productId:pId,
      productName:pName,
      productDescription:pDes,
      productPrice:pPrice
    });
  }

}
