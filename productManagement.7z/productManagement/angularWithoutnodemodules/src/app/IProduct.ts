export interface IProducts{
    productId:number;
    productName:String;
    productDescription:string;
    productPrice:number;
}