import { Component, OnInit } from '@angular/core';
import {IProducts} from '../IProduct';
import {ProductDisplayService} from '../product-display.service';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  constructor(private productDisplayService:ProductDisplayService) { }
 
  products:IProducts[];
    
  p=1;
  
  ngOnInit() {
    this.getData();
  }

  getData(){
    this.productDisplayService.getData().subscribe(product=>this.products=product);
    
  }

  DeleteProduct(productId){
       this.productDisplayService.DeleteData(productId).subscribe(product=>this.products=product);
  }

  addProduct(form:NgForm){
      var val=form.value;
      this.productDisplayService.postData(val.id,val.name,val.description,val.price).subscribe(product=>this.products=product);
      form.reset();
  }

}
