import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-display',
  templateUrl: './angular-display.component.html',
  styleUrls: ['./angular-display.component.css']
})
export class AngularDisplayComponent implements OnInit{

  id:number;
  name:string;
  salary:number;
  department:string;

  id1:number;
  name1:string;
  salary1:number;
  department1:string;
  Employee:any[]=[
     {
      
        "empId":1001,
        "empName":"Rahul",
        "empSal":9000,
        "empDep":"Java"
      },
      {
        "empId":1002,
        "empName":"Sachin",
        "empSal":19000,
        "empDep":"OraApps"
      },
      {
        "empId":1003,
        "empName":"Vikash",
        "empSal":29000,
        "empDep":"BI"
      }
  ];

  constructor() { }

  Update(u):void
  {
      for(var p=0;p<this.Employee.length;p++)
      {
        if(this.Employee[p].empId==u)
        {
           this.id1=this.Employee[p].empId;
           this.name1=this.Employee[p].empName;
           this.salary1=this.Employee[p].empSal;
           this.department1=this.Employee[p].empDep;
        }
     } 
  }

  Update1(update):void
  {
     update.preventDefault();
     for(var p=0;p<this.Employee.length;p++)
     {
        if(this.Employee[p].empId==update.target.elements[0].value)
        {
          this.Employee[p].empName=update.target.elements[1].value;
          this.Employee[p].empSal=update.target.elements[2].value;
          this.Employee[p].empDep=update.target.elements[3].value;
        }
       
     }  
  }

  Display(e):void
  {
      e.preventDefault();
      this.id=e.target.elements[0].value;
      this.name=e.target.elements[1].value;
      this.salary=e.target.elements[2].value;
      this.department=e.target.elements[3].value;
      var emp=JSON.parse(`{"empId":${this.id},"empName":"${this.name}","empSal":${this.salary},"empDep":"${this.department}"}`);
      this.Employee.push(emp);
  }
  
  Delete(i):void
  {
     
     for(var p=0;p<this.Employee.length;p++)
     {
        if(this.Employee[p].empId==i)
        {
          this.Employee.splice(p,1);
        }
       
     } 
  }

  ngOnInit() {
  }

}
