import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sort-list',
  templateUrl: './sort-list.component.html',
  styleUrls: ['./sort-list.component.css']
})
export class SortListComponent implements OnInit {

  Employee: any[] = [
    {
      "empId": 1001,
      "empName": "Rahul",
      "empSal": 9000,
      "empDep": "JAVA",
      "empjoiningdate": "6/12/2014"
    },
    {
      "empId": 1002,
      "empName": "Vikash",
      "empSal": 11000,
      "empDep": "ORAAPS",
      "empjoiningdate": "6/12/2017"
    },
    {
      "empId": 1003,
      "empName": "Uma",
      "empSal": 12000,
      "empDep": "JAVA",
      "empjoiningdate": "6/12/2010"
    },
    {
      "empId": 1004,
      "empName": "Sachin",
      "empSal": 11500,
      "empDep": "ORAAPS",
      "empjoiningdate": "11/12/2017"
    },
    {
      "empId": 1005,
      "empName": "Amol",
      "empSal": 7000,
      "empDep": ".NET",
      "empjoiningdate": "1/1/2018"
    },
    {
      "empId": 1006,
      "empName": "Vishal",
      "empSal": 17000,
      "empDep": "BI",
      "empjoiningdate": "9/12/2012"
    },
    {
      "empId": 1007,
      "empName": "Rajita",
      "empSal": 21000,
      "empDep": "BI",
      "empjoiningdate": "6/7/2014"
    }
  ];

  constructor() { }

  sortId(): void {
    this.Employee.sort(function (a, b) {
      if (a.empId < b.empId)
        return -1;
      if (a.empId > b.empId)
        return 1;
      return 0;
    });
  }

  sortName(): void {
      this.Employee.sort(function (a, b) {
      if (a.empName < b.empName)
        return -1;
      if (a.empName > b.empName)
        return 1;
      return 0;
    });
  }

  sortSalary(): void {
     this.Employee.sort(function (a, b) {
      if (a.empSal < b.empSal)
        return -1;
      if (a.empSal > b.empSal)
        return 1;
      return 0;
    });
  }

  sortDepartment(): void {
     this.Employee.sort(function (a, b) {
      if (a.empDep < b.empDep)
        return -1;
      if (a.empDep > b.empDep)
        return 1;
      return 0;
    });
  }

  ngOnInit() {
  }

}
