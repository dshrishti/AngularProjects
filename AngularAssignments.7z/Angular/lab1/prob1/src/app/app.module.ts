import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {Router,RouterModule} from '@angular/router';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { AngularDisplayComponent } from './angular-display/angular-display.component';

@NgModule({
  declarations: [
    AppComponent,
    AngularDisplayComponent
  ],
  imports: [
    BrowserModule,FormsModule,
     RouterModule.forRoot([
         {
            path: '',
            component: AngularDisplayComponent
         }
      ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
