import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-display',
  templateUrl: './angular-display.component.html',
  styleUrls: ['./angular-display.component.css']
})
export class AngularDisplayComponent implements OnInit {
  id:number;
  name:string;
  salary:number;
  department:string;
  
  constructor() { }

  Display(e):void
  {
    e.preventDefault();
    this.id=e.target.elements[0].value;
    this.name=e.target.elements[1].value;
    this.salary=e.target.elements[2].value;
    this.department=e.target.elements[3].value;
    alert(this.id+" "+this.name+" "+this.salary+" "+this.department);
  }

  ngOnInit() {
  }

}
