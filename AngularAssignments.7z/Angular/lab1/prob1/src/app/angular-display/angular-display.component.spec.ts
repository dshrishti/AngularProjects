import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AngularDisplayComponent } from './angular-display.component';

describe('AngularDisplayComponent', () => {
  let component: AngularDisplayComponent;
  let fixture: ComponentFixture<AngularDisplayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AngularDisplayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AngularDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
