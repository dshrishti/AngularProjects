import { Component } from '@angular/core';
@Component({
    selector:'app-form',
    templateUrl:'./form.component.html',
    styleUrls:['./form.component.css']
})

export class FormComponent{
    pageTitle:string="Angular 2 operation";
    categories:string[]=["Grocery", "Mobile", "Electronics", "Clothes"];
    productAvailable:string[]=['Big Bazar','DMart','Reliance','Mega Store'];
    storeList:string[]=[];
    storeVar:boolean=false;
   
    addStore(store:string):void{
        let s:number=this.storeList.indexOf(store);
        if(s!=-1){
            this.storeList.splice(s,1);
        }
        else{
        this.storeList.push(store);
        }
    }
    storeCheck(store:string):void{
            this.storeVar=true;
    }

    showOnConsole(formValues):void{
        
        console.log("product Id:"+formValues.productId);
        console.log("product Name:"+formValues.productName);
        console.log("product Cost:"+formValues.productCost);
        console.log("product Available online:"+formValues.onlineRadio);
         console.log("product Category:"+formValues.Category);
          console.log("product vailable on stores:");

        
        for(let product of this.storeList){
             console.log(product);
        }
    }
}