import { Injectable } from '@angular/core';
import {IBook} from './books/IBook';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http'; 

@Injectable({
providedIn: 'root'
})
export class BookserviceService {

constructor(private http:HttpClient) { }
public url='../assets/booklist.json';


ngOnInit(){
this.getBookList();
}
getBookList():Observable<IBook[]>{
return this.http.get<IBook[]>(this.url);
}
} 