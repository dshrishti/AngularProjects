import { Pipe, PipeTransform } from '@angular/core';
import {IBook} from './books/IBook';

@Pipe({
  name: 'year'
})
export class YearPipe implements PipeTransform {

  str:string;
  transform(books: IBook[], args: IBook[]): IBook[] {
    if(!books)
    return [];
    if(!args)
    return books;
    this.str=args.toString().toLocaleLowerCase();
    return books.filter(book=>
    book.year.toString().toLocaleLowerCase().includes(this.str));
  }

}
