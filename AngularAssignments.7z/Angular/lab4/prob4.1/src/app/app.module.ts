import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { BooksComponent } from './books/books.component';
import { HttpClientModule } from '@angular/common/http';
import { IdPipe } from './id.pipe';
import { TitlePipe } from './title.pipe';
import { AuthorPipe } from './author.pipe';
import { YearPipe } from './year.pipe';

@NgModule({
  declarations: [
    AppComponent,
    BooksComponent,
    IdPipe,
    TitlePipe,
    AuthorPipe,
    YearPipe
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
