import { IdPipe } from './id.pipe';

describe('IdPipe', () => {
  it('create an instance', () => {
    const pipe = new IdPipe();
    expect(pipe).toBeTruthy();
  });
});
