import { Pipe, PipeTransform } from '@angular/core';
  import {IBook} from './books/IBook';

@Pipe({
  name: 'id'
})
export class IdPipe implements PipeTransform {

  str:string;
transform(books: IBook[], args: string[]): IBook[] {
if(!books) return [];
if(!args) return books;
this.str = args.toString().toLocaleLowerCase();
return books.filter( book => 
book.id.toString().toLocaleLowerCase().includes(this.str)
);
}

}
