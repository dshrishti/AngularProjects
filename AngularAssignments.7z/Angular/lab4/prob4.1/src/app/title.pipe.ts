import { Pipe, PipeTransform } from '@angular/core';
import {BookserviceService} from './bookservice.service';
import {IBook} from './books/IBook';

@Pipe({
  name: 'title'
})
export class TitlePipe implements PipeTransform {

  str:string;
  transform(books: IBook[], args: IBook[]): IBook[] {
    if(!books)
    return [];
    if(!args)
    return books;
    this.str=args.toString().toLocaleLowerCase();
    return books.filter(book=>
    book.title.toString().toLocaleLowerCase().includes(this.str));
  }

}
