import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import {BookserviceService} from '../bookservice.service';
import {IBook} from './IBook';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {
  idSearch:number;
  titleSearch:string;
  authorSearch:string;
  yearSearch:number;

  constructor(private bookService:BookserviceService) { }
  books:IBook[];

  ngOnInit() {
    this.getBookList();
  }

  getBookList():void{
this.bookService.getBookList().subscribe(books=>this.books=books);

}
}
