import { Pipe, PipeTransform } from '@angular/core';
import {IBook} from './books/IBook';

@Pipe({
  name: 'author'
})
export class AuthorPipe implements PipeTransform {

  str:string;
  transform(books: IBook[], args: IBook[]): IBook[] {
    if(!books) 
    return [];
    if(!args)
    return books;
    this.str=args.toString().toLocaleLowerCase();
    return books.filter(book=>
    book.author.toString().toLocaleLowerCase().includes(this.str));
  }

}
